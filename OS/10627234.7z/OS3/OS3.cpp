# include <stdio.h>
# include <stdlib.h>
# include <string.h>
# include <iostream>
# include <vector>
# include <string>
# include <fstream>
# include <math.h>
using namespace std;
struct Page {
	int num ;
	int shift[9] ;
	int reb ;
	int stamp ;
};

int Bvalue( int shift[9] ) {
  int value = 0 ;
  for ( int i = 8 ; i >= 0 ; i-- ) {
  	if ( shift[i] == 1 )
  		value = value + pow( 2, -( i - 8 ) ) ;
  	else
  		;
  }	
  
  return value ;
}

bool Exist( vector<int> queue, int id ) {
	for ( int i = 0 ; i < queue.size() ; i++ ) {
		if ( id == queue[i] )
			return true ;
	}
	
	return false ;
}

int main() {
	fstream file ;
	fstream out_file ;
	int fault = 0 ;
	bool havefault = false ;
	string filename ;
	cout << "�п�J�ɮצW��:" ;
	cin >> filename ; 
	file.open( filename, ios::in ) ;
	out_file.open( "output.txt", ios::out ) ;
	vector<int> data ;
	int frame = 0 ;
	char ch = '\0' ;
	file >> frame ;
    vector<int> queue ;


	file.get( ch ) ; // Ū�մ��� 
	while ( file.get( ch ) ) {
		if ( ch == '\n' )
			break ;
		data.push_back( ch - '0' ) ;
	}
	
	file.close() ;
    out_file << "--------------FIFO-----------------------\n" ;
    for ( int i = 0 ; i < data.size() ; i++ ) {

    	out_file << data[i] << "\t\t" ;

    	if ( queue.size() < frame ) {
    		queue.insert( queue.begin(), data[i] ) ;
    		fault++ ;
    		havefault = true ;
    	}
    	else {
    		if ( Exist( queue, data[i]) ) {
				;
    		}
    		else {
    			queue.erase( queue.begin() + queue.size() - 1 ) ;
    			queue.insert( queue.begin(), data[i] ) ;
    			fault++ ;
    			havefault = true ;
			}
		}
		
		for ( int j = 0 ; j < queue.size() ; j++ ) {
			out_file << queue[j] ;
		}
		
		if ( havefault )
		  out_file << "\t\tF\n" ;
		else
		  out_file << "\n" ;
		  
		havefault = false ;
    	
	}
	
	out_file << "Page Fault = " << fault << "  Page Replaces = " << fault - frame << "  Page Frames = " << frame << "\n" ;
	
	fault = 0 ;
	havefault = false ;
	queue.clear() ;
    out_file << "\n--------------LRU-----------------------\n" ;
    for ( int i = 0 ; i < data.size() ; i++ ) {

    	out_file << data[i] << "\t\t" ;

    	if ( queue.size() < frame ) {
    		queue.insert( queue.begin(), data[i] ) ;
    		fault++ ;
    		havefault = true ;
    	}
    	else {
    		if ( Exist( queue, data[i]) ) {
    			queue.insert( queue.begin(), data[i] ) ;
				for ( int k = 1 ; k < queue.size() ; k++ ) {
					if ( data[i] == queue[k] ) {
						queue.erase( queue.begin() + k ) ;
						break ;
					}
				}
    		}
    		else {
    			queue.erase( queue.begin() + queue.size() - 1 ) ;
    			queue.insert( queue.begin(), data[i] ) ;
    			fault++ ;
    			havefault = true ;
			}
		}
		
		for ( int j = 0 ; j < queue.size() ; j++ ) {
			out_file << queue[j] ;
		}
		
		if ( havefault )
		  out_file << "\t\tF\n" ;
		else
		  out_file << "\n" ;
		  
		havefault = false ;
    	
	}
	
	out_file << "Page Fault = " << fault << "  Page Replaces = " << fault - frame << "  Page Frames = " << frame << "\n" ;
	
	
	vector<Page> memory ;
	Page page ;
	bool test = true ;
	for ( int j = 0 ; j < 9 ; j++ ) page.shift[j] = 0 ;

	for ( int i = 0 ; i < data.size() ; i++ ) {
		for ( int k = 0 ; k < memory.size() ; k++ ) {
			if ( memory[k].num == data[i] ) {
				test = false ;
			}
			
		}
		
		if ( test ) {
			page.num = data[i] ;
			memory.push_back( page ) ;
			for ( int j = 0 ; j < 9 ; j++ ) page.shift[j] = 0 ;
		}
        
        test = true ;
	}


	fault = 0 ;
	havefault = false ;
	int index = 0 ;
	int small = 0 ;
	int temp = 0 ;
	queue.clear() ;
    out_file << "\n--------------Additional Reference Bits-----------------------\n" ;
    for ( int i = 0 ; i < data.size() ; i++ ) {

    	out_file << data[i] << "\t\t" ;

    	if ( queue.size() < frame ) {
    		queue.insert( queue.begin(), data[i] ) ;
    		fault++ ;
    		havefault = true ;
    		for ( int j = 0 ; j < memory.size() ; j++ ) {
				if ( memory[j].num == data[i] ) {
					
    				memory[j].shift[0] = 1 ;
    				break ;
    			}
    		}
    	}
    	else {
    		if ( Exist( queue, data[i] ) ) {
    			for ( int j = 0 ; j < memory.size() ; j++ ) {
					if ( memory[j].num == data[i] ) {
						
    					memory[j].shift[0] = 1 ;
    					break ;
    				}
    			}
    		}
    		else {
    			for ( int j = 0 ; j < memory.size() ; j++ ) {
    				if ( memory[j].num == queue[0] ) {
    					small = j ;
    				}
 
				}

    			for ( int j = 0 ; j < queue.size() ; j++ ) {
    				for ( int k = 0 ; k < memory.size() ; k++ ) {
    					if ( memory[k].num == queue[j] ) {
    						if ( Bvalue( memory[k].shift ) < Bvalue( memory[small].shift ) ) {
    							small = k ;
    							index = j ;
    						}
    					}
    				} 
				}
				
    			queue.erase( queue.begin() + index ) ;
    			queue.insert( queue.begin(), data[i] ) ;
    			for ( int j = 0 ; j < memory.size() ; j++ ) {
					if ( memory[j].num == data[i] ) {
					
    					memory[j].shift[0] = 1 ;
    					break ;
    				}
    			}

    			fault++ ;
    			havefault = true ;
			}
		}
		
		for ( int j = 0 ; j < queue.size() ; j++ ) {
			out_file << queue[j] ;
		}
		
		if ( havefault )
		  out_file << "\t\tF\n" ;
		else
		  out_file << "\n" ;
		  
		havefault = false ;
		small = 0 ;
		index = 0 ;
		for ( int j = 0 ; j < memory.size() ; j++ ) {
			for ( int k = 8 ; k >= 1 ; k-- ) {
				memory[j].shift[k] = memory[j].shift[k-1] ;
				
			}
			
			memory[j].shift[0] = 0 ;
		}
    	
	}
	
	out_file << "Page Fault = " << fault << "  Page Replaces = " << fault - frame << "  Page Frames = " << frame << "\n" ;
	
	

	memory.clear() ;

	test = true ;
	for ( int j = 0 ; j < 9 ; j++ ) page.shift[j] = 0 ;

	for ( int i = 0 ; i < data.size() ; i++ ) {
		for ( int k = 0 ; k < memory.size() ; k++ ) {
			if ( memory[k].num == data[i] ) {
				test = false ;
			}
			
		}
		
		if ( test ) {
			page.num = data[i] ;
			page.reb = 0 ;
			memory.push_back( page ) ;
			for ( int j = 0 ; j < 9 ; j++ ) page.shift[j] = 0 ;
		}
        
        test = true ;
	}

	fault = 0 ;
	havefault = false ;
	index = 0 ;
	small = 0 ;
	temp = 1 ;
	queue.clear() ;
	vector<int> tempqueue ;
	bool findzero = false ;
	int temp2 = 0 ;
    out_file << "\n--------------Second chance Page-----------------------\n" ;
    for ( int i = 0 ; i < data.size() ; i++ ) {

    	out_file << data[i] << "\t\t" ;

    	if ( queue.size() < frame ) {
    		queue.insert( queue.begin(), data[i] ) ;
    		fault++ ;
    		havefault = true ;
    		for ( int j = 0 ; j < memory.size() ; j++ ) { 
				if ( memory[j].num == data[i] ) {
					memory[j].reb = 1 ;
    				// memory[j].shift[0] = 1 ;
    				break ;
    			}
    		}
    	}
    	else {
    		if ( Exist( queue, data[i] ) ) {
    			for ( int j = 0 ; j < memory.size() ; j++ ) {
					if ( memory[j].num == data[i] ) {
						memory[j].reb = 1 ;
    					// memory[j].shift[0] = 1 ;
    					break ;
    				}
    			}
    		}
    		else {
    			while ( !findzero ) {
    				for ( int j = 0 ; j < memory.size() ; j++ ) {
    					if ( memory[j].num == queue[frame-1] ) {
    						if ( memory[j].reb == 0 ) {
    							findzero = true ;
    							index = frame-1 ;
							}
							else {
								// tempqueue.push_back( memory[j].num ) ;
								// temp2 = queue[frame-temp] ;
								memory[j].reb = 0 ;
								queue.insert( queue.begin(), queue[frame-1] ) ;
								queue.erase( queue.begin() + frame ) ;

								temp2 = 0 ;
								temp++ ;
								if ( temp > frame ) {
									findzero = true ;
									index = frame - 1 ;
								}
							}
    					}
 
					}
				}

				/*if ( temp > frame ) {
					queue = tempqueue ;
    				queue.erase( queue.begin()) ;
    				queue.insert( queue.begin(), data[i] ) ;
				}*/

    			queue.erase( queue.begin() + index ) ;
    			queue.insert( queue.begin(), data[i] ) ;
    			/*
				if ( queue[1] == data[i-1] ) {
					;
				}
				else {
					queue[1] = data[i-1] ;
					queue[2] = data[i-2] ;
				}
*/
/*
				for ( int j = 0 ; j < queue.size() ; j++ ) {
					for ( int k = 0 ; k < memory.size() ; k++ ) {
						if ( queue[j] == memory[k].num ) {
							memory[k].reb = 0 ; 
						}
					}
				}*/
    			for ( int j = 0 ; j < memory.size() ; j++ ) {
					if ( memory[j].num == data[i] ) {
						memory[j].reb = 1 ;
    					// memory[j].shift[0] = 1 ;
    					break ;
    				}
    			}

    			fault++ ;
    			havefault = true ;
			}
		}
		
		for ( int j = 0 ; j < queue.size() ; j++ ) {
			out_file << queue[j] ;
		}
		
		if ( havefault )
		  out_file << "\t\tF\n" ;
		else
		  out_file << "\n" ;
		  
		tempqueue.clear() ;
		findzero = false ;
		havefault = false ;
    	temp = 1 ;
    	index = 0 ;
	}
	
	out_file << "Page Fault = " << fault << "  Page Replaces = " << fault - frame << "  Page Frames = " << frame << "\n" ;
	
	
	
	memory.clear() ;

	test = true ;
	for ( int j = 0 ; j < 9 ; j++ ) page.shift[j] = 0 ;

	for ( int i = 0 ; i < data.size() ; i++ ) {
		for ( int k = 0 ; k < memory.size() ; k++ ) {
			if ( memory[k].num == data[i] ) {
				test = false ;
			}
			
		}
		
		if ( test ) {
			page.num = data[i] ;
			page.reb = 0 ;
			page.stamp = 0 ;
			memory.push_back( page ) ;
			for ( int j = 0 ; j < 9 ; j++ ) page.shift[j] = 0 ;
		}
        
        test = true ;
	}

	fault = 0 ;
	havefault = false ;
	index = 0 ;
	small = 0 ;
	temp = 1 ;
	queue.clear() ;
	findzero = false ;
    out_file << "\n--------------Least Frequently Used Page Replacement -----------------------\n" ;
    for ( int i = 0 ; i < data.size() ; i++ ) {

    	out_file << data[i] << "\t\t" ;

    	if ( queue.size() < frame ) {
    		queue.insert( queue.begin(), data[i] ) ;
    		fault++ ;
    		havefault = true ;
			for ( int j = 0 ; j < queue.size() ; j++ ) {
				for ( int k = 0 ; k < memory.size() ; k++ ) {
					if ( queue[j] == memory[k].num ) {
						memory[k].stamp++ ;

					}
				}
			}

    		for ( int j = 0 ; j < memory.size() ; j++ ) {
				if ( memory[j].num == data[i] ) {
					memory[j].reb++ ;
					page.stamp = 1 ;
    				// memory[j].shift[0] = 1 ;
    				break ;
    			}
    		}
    		
    	}
    	else {
    		if ( Exist( queue, data[i] ) ) {
    			for ( int j = 0 ; j < memory.size() ; j++ ) {
					if ( memory[j].num == data[i] ) {
						memory[j].reb++ ;
						memory[j].stamp = 1 ;
    					// memory[j].shift[0] = 1 ;
    					break ;
    				}
    			}
    			
				for ( int j = 0 ; j < queue.size() ; j++ ) {
					for ( int k = 0 ; k < memory.size() ; k++ ) {
						if ( queue[j] == memory[k].num ) {
							memory[k].stamp++ ;

						}
					}
				}
    		}
    		else {
    			for ( int j = 0 ; j < memory.size() ; j++ ) {
    				if ( memory[j].num == queue[0] ) {
    					small = j ;
    					index = 0 ;
					}
    				
				}
				for ( int j = 0 ; j < queue.size() ; j++ ) {
					for ( int k = 0 ; k < memory.size() ; k++ ) {
						if ( queue[j] == memory[k].num ) {
							if ( memory[k].reb < memory[small].reb ) {
								small = k ;
								index = j ;
							}
							else if ( memory[k].reb == memory[small].reb ) {
								if ( memory[k].stamp > memory[small].stamp ) {
									small = k ;
									index = j ;
								
								}
							}
						}
					}
				}

				for ( int j = 0 ; j < memory.size() ; j++ ) {
					if ( memory[j].num == queue[index] ) {
						memory[j].reb= 0 ;
					}
				}
    			queue.erase( queue.begin() + index ) ;
    			queue.insert( queue.begin(), data[i] ) ;
    			
				for ( int j = 0 ; j < queue.size() ; j++ ) {
					for ( int k = 0 ; k < memory.size() ; k++ ) {
						if ( queue[j] == memory[k].num ) {

							// memory[k].reb = 0 ; 
							memory[k].stamp++ ;
						}
					}
				}
				

    			for ( int j = 0 ; j < memory.size() ; j++ ) {
					if ( memory[j].num == data[i] ) {
						memory[j].reb++ ;
						memory[j].stamp = 1 ;
    					// memory[j].shift[0] = 1 ;
    					break ;
    				}
    			}

    			fault++ ;
    			havefault = true ;
			}
		}
		
		for ( int j = 0 ; j < queue.size() ; j++ ) {
			out_file << queue[j] ;
		}
		
		if ( havefault )
		  out_file << "\t\tF\n" ;
		else
		  out_file << "\n" ;
		  
		findzero = false ;
		havefault = false ;
    	temp = 1 ;
    	index = 0 ;
    	small = 0 ;
	}
	
	out_file << "Page Fault = " << fault << "  Page Replaces = " << fault - frame << "  Page Frames = " << frame << "\n" ;
	
	
	memory.clear() ;

	test = true ;
	for ( int j = 0 ; j < 9 ; j++ ) page.shift[j] = 0 ;

	for ( int i = 0 ; i < data.size() ; i++ ) {
		for ( int k = 0 ; k < memory.size() ; k++ ) {
			if ( memory[k].num == data[i] ) {
				test = false ;
			}
			
		}
		
		if ( test ) {
			page.num = data[i] ;
			page.reb = 0 ;
			page.stamp = 0 ;
			memory.push_back( page ) ;
			for ( int j = 0 ; j < 9 ; j++ ) page.shift[j] = 0 ;
		}
        
        test = true ;
	}

	fault = 0 ;
	havefault = false ;
	index = 0 ;
	small = 0 ;
	temp = 1 ;
	queue.clear() ;
	findzero = false ;
    out_file << "\n--------------Most Frequently Used Page Replacement -----------------------\n" ;
    for ( int i = 0 ; i < data.size() ; i++ ) {

    	out_file << data[i] << "\t\t" ;

    	if ( queue.size() < frame ) {
    		queue.insert( queue.begin(), data[i] ) ;
    		fault++ ;
    		havefault = true ;
			for ( int j = 0 ; j < queue.size() ; j++ ) {
				for ( int k = 0 ; k < memory.size() ; k++ ) {
					if ( queue[j] == memory[k].num ) {
						memory[k].stamp++ ;

					}
				}
			}

    		for ( int j = 0 ; j < memory.size() ; j++ ) {
				if ( memory[j].num == data[i] ) {
					memory[j].reb++ ;
					page.stamp = 1 ;
    				// memory[j].shift[0] = 1 ;
    				break ;
    			}
    		}
    		
    	}
    	else {
    		if ( Exist( queue, data[i] ) ) {
    			for ( int j = 0 ; j < memory.size() ; j++ ) {
					if ( memory[j].num == data[i] ) {
						memory[j].reb++ ;
						memory[j].stamp = 1 ;
    					// memory[j].shift[0] = 1 ;
    					break ;
    				}
    			}
    			
				for ( int j = 0 ; j < queue.size() ; j++ ) {
					for ( int k = 0 ; k < memory.size() ; k++ ) {
						if ( queue[j] == memory[k].num ) {
							memory[k].stamp++ ;

						}
					}
				}
    		}
    		else {
    			for ( int j = 0 ; j < memory.size() ; j++ ) {
    				if ( memory[j].num == queue[0] ) {
    					small = j ;
    					index = 0 ;
					}
    				
				}
				for ( int j = 0 ; j < queue.size() ; j++ ) {
					for ( int k = 0 ; k < memory.size() ; k++ ) {
						if ( queue[j] == memory[k].num ) {
							if ( memory[k].reb > memory[small].reb ) {
								small = k ;
								index = j ;
							}
							else if ( memory[k].reb == memory[small].reb ) {
								if ( memory[k].stamp > memory[small].stamp ) {
									small = k ;
									index = j ;
								
								}
							}
						}
					}
				}

				for ( int j = 0 ; j < memory.size() ; j++ ) {
					if ( memory[j].num == queue[index] ) {
						memory[j].reb= 0 ;
					}
				}
				// cout << memory[small].num ;
    			queue.erase( queue.begin() + index ) ;
    			queue.insert( queue.begin(), data[i] ) ;
    			
				for ( int j = 0 ; j < queue.size() ; j++ ) {
					for ( int k = 0 ; k < memory.size() ; k++ ) {
						if ( queue[j] == memory[k].num ) {

							// memory[k].reb = 0 ; 
							memory[k].stamp++ ;
						}
					}
				}
				

    			for ( int j = 0 ; j < memory.size() ; j++ ) {
					if ( memory[j].num == data[i] ) {
						memory[j].reb++ ;
						memory[j].stamp = 1 ;
    					// memory[j].shift[0] = 1 ;
    					break ;
    				}
    			}

    			fault++ ;
    			havefault = true ;
			}
		}
		
		for ( int j = 0 ; j < queue.size() ; j++ ) {
			out_file << queue[j] ;
		}
		
		if ( havefault )
		  out_file << "\t\tF\n" ;
		else
		  out_file << "\n" ;
		  
		findzero = false ;
		havefault = false ;
    	temp = 1 ;
    	index = 0 ;
    	small = 0 ;
	}
	
	out_file << "Page Fault = " << fault << "  Page Replaces = " << fault - frame << "  Page Frames = " << frame << "\n" ;
	
}
