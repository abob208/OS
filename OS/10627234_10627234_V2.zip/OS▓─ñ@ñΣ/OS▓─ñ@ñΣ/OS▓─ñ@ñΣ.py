import time
import queue
import threading
import multiprocessing 

def GetList( file ):
    all_number = file.read() 
    all_number = all_number.split()
    int_list = list( map( int, all_number ) )
    return int_list

def GetSepList( sepnum, file ):
    int_list = GetList( file )
    len_list = len( int_list )
    n = len_list / sepnum
    n = int( n )
    all_sep_ls = [ int_list[ i:i + n ] for i in range( 0, n * sepnum, n ) ] 
    all_sep_ls[ sepnum - 1 ].extend( int_list[ n * sepnum : len_list ] ) 
    return all_sep_ls

def BubbleSort( list, queue ):
   for i in range(len(list)):
        for j in range(len(list) - 1 - i ):
            if list[j] > list[ j + 1 ]:
                list[j], list[j + 1] = list[j + 1], list[j]
   queue.put(list)

def MergeSort( list1, list2, queue ):
    i = 0
    j = 0
    sort_list = []
    
    while i < len( list1 ) and j < len( list2 ):
        if list1[i] < list2[j]:
            sort_list.append(list1[i])
            i = i + 1
        else :
            sort_list.append(list2[j])
            j = j + 1

    if i == len( list1 ) :
        sort_list.extend( list2[j:len( list2 ) ] )
    elif j == len( list2 ) :
        sort_list.extend( list1[i:len( list1 ) ] )

    queue.put(sort_list)

def BubbleAndMerge( All_list, queue ):
    for list in All_list:
        BubbleSort( list, queue )

    while queue.qsize() > 1:
        list1 = queue.get()
        list2 = queue.get()
        MergeSort( list1, list2, queue )

def WriteFile(fileName, list, perf_time):
    fileName = fileName[0:len(fileName) - 4]
    file = open(fileName + '_output.txt', "w")
    
    file.write('排序:\n')
    for i in list:
        file.write(str(i) + ' ')
    file.write( '\n執行時間 : {:.6f} 秒'.format( perf_time ) )
    file.close()


def Command1( fileName, file ):
    list = GetList( file )
    queue2 = queue.Queue(len(list))

    start = time.perf_counter()

    BubbleSort( list, queue2 )

    process_time = time.perf_counter() - start
    print('執行時間: ' + str(process_time))
    WriteFile(fileName, list, process_time)

def Command2( fileName,file ):
    all_threads = []
    all_merge_threads = []

    sepnum = input('請輸入要切成幾份:')
    sepnum = int(sepnum)
    all_sep_list = GetSepList( sepnum, file )
    queue2 = queue.Queue(sepnum)

    i = 0
    j = 0
    for i in range(sepnum):
        temp = threading.Thread(name = 'bubblesort_thread' + str(i), target=BubbleSort, args=( all_sep_list[i], queue2 ) )
        all_threads.append( temp )

    start = time.perf_counter()

    i = 0
    j = 0
    while i < sepnum or j < sepnum - 1: 
        if i < sepnum:
            all_threads[i].start()
            i = i +  1
        if queue2.qsize() > 1: 
            list1 = queue2.get()
            list2 = queue2.get()
            temp = threading.Thread(name = 'mergesort_thread' + str(j), target=MergeSort, args=( list1, list2, queue2 ) )
            temp.start()
            all_merge_threads.append( temp )
            j = j + 1

    for merge_process in all_merge_threads:
        merge_process.join()
    
    process_time = time.perf_counter() - start

    print('執行時間: ' + str(process_time))
    WriteFile(fileName, queue2.get(), process_time)

def Command3( fileName, file ):
    all_bubble_processes = []
    all_merge_processes = []

    sepnum = input('請輸入要切成幾份:')
    sepnum = int(sepnum)
    all_sep_list = GetSepList( sepnum, file )
    manager = multiprocessing.Manager()
    queue = manager.Queue(sepnum)

    for i in range(sepnum):
        p = multiprocessing.Process( name ='bublesort_precess' + str( i ), target=BubbleSort, args=( all_sep_list[i], queue) )
        all_bubble_processes.append(p)

    start = time.perf_counter()
    i = 0
    j = 0
    while i < sepnum or j < sepnum - 1:
        if i < sepnum:
            all_bubble_processes[i].start()
            i = i + 1
        if queue.qsize() > 1:
            list1 = queue.get()
            list2 = queue.get()
            temp = multiprocessing.Process( name='mergersort_process' + str( j ), target=MergeSort, args=( list1, list2, queue ) )
            temp.start()
            all_merge_processes.append( temp )
            j = j + 1

    for merge_process in all_merge_processes:
        merge_process.join()

    process_time = time.perf_counter() - start

    print('執行時間: ' + str(process_time))
    WriteFile(fileName, queue.get(), process_time)


def Command4( fileName, file ):
    sepnum = input('請輸入要切成幾份:')
    sepnum = int(sepnum)
    sep_list = GetSepList( sepnum, file )
    manager = multiprocessing.Manager()
    queue = manager.Queue(sepnum)

    start = time.perf_counter()

    BubbleMergeSort = multiprocessing.Process( target = BubbleAndMerge, args = ( sep_list, queue ) )
    BubbleMergeSort.start()
    BubbleMergeSort.join()

    process_time = time.perf_counter() - start

    print( '執行時間: ' + str( process_time ) )
    WriteFile( fileName, queue.get(), process_time )

if __name__ == '__main__':
    fileName = input('請輸入檔案名稱:')
    file = open(fileName , "r")
    command = file.read(1)
    
    if command == '1':
        Command1(fileName, file)
    elif command == '2':
        Command2(fileName, file)
    elif command == '3':
        Command3(fileName, file)
    elif command == '4':
        Command4(fileName, file)

    print('排序完成')
